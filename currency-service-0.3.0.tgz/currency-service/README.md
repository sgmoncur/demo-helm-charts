# Demo Currency Service Helm Chart

This demo depends on the [currency-service](https://github.com/sgmoncur/currency-service) project.

## Starting

To install type `helm install <name> .` where `<name>` is a label of choice.
For example, `helm install currency-service .`.

## Status Check

Use `kubectl describe pods` or `kubectl describe pod <pod-name>`. You should
see that the container image is pulled and started correctly.

## Testing

Port-forwarding may be used to test end-points, for example:

`kubectl get pods`

Note the pod's name, then:

`kubectl port-forward <pod-name> 8080`

Replace `<pod-name>` with the running pod's name. Then it's possible to use
localhost:8080 to communicate with the running container, e.g.:

```bash
curl -v -X POST http://localhost:8080/currencies -H "Content-Type: application/json" -d '{"code":"GBP","name":"Pound Sterling", "digitsAfterDecimal": 2, "number": 826}'
```

```bash
curl -X GET http://localhost:8080/currencies
```

## Stopping

`helm uninstall <name>`. For example `helm uninstall redis-demo`.

