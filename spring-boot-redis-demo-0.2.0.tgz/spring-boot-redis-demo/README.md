# Demo Spring Boot Redis Helm Chart

This demo depends on the [spring-boot-redis-demo](https://github.com/sgmoncur/spring-boot-redis-demo) project.

## Starting

To install type `helm install <name> .` where `<name>` is a label of choice.
For example, `helm install redis-demo .`.

## Status Check

Use `kubectl describe pods` or `kubectl describe pod <pod-name>`. You should
see that the container image is pulled and started correctly.

## Testing

Port-forwarding may be used to test end-points, for example:

`kubectl get pods`

Note the pod's name, then:

`kubectl port-forward <pod-name> 8080`

Replace `<pod-name>` with the running pod's name. Then it's possible to use
localhost:8080 to communicate with the running container, e.g.:

```bash
curl -v -X POST http://localhost:8080/countries -H "Content-Type: application/json" -d '{"code":"GB", "name":"Great Britain"}'
```

```bash
curl -X GET http://localhost:8080/countries
```

## Stopping

`helm uninstall <name>`. For example `helm uninstall redis-demo`.

